#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVBoxLayout>
#include <QHBoxLayout>

#include <QComboBox>
#include <QPushButton>
#include <QVBoxLayout>
#include <QLabel>
#include <QScrollArea>
#include <QDebug>
#include <QSlider>

#include <QTabWidget>
#include <QListWidget>
#include "camera.h"

using namespace std;
using namespace cv;

class Camera;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
private:
    QWidget *mainWidget;        /* 主容器，Widget也可以当作一种容器 */
    QScrollArea *scrollArea,*gun1,*gun2;    /* 滚动区域，方便开发高分辨率 */
    QLabel *displayLabel,*chu,*chu2;       /* 将采集到的图像使用Widget显示 */
    QHBoxLayout *hboxLayout;    /* 界面右侧区域布局 */
    QVBoxLayout *vboxLayout,*shu;    /* 界面右侧区域布局 */
    QHBoxLayout *heng,*heng1,*heng2;
    QWidget *up,*right,*tu,*xia;            /* 界面右侧区域容器 */
    QSlider *hua;
    QSlider *hua1;

    QLabel *photoLabel;         /* 界面右侧区域显示拍照的图片 */
    QComboBox *comboBox;        /* 界面右侧区域摄像头设备下拉选择框 */
    QPushButton *pushButton[6]; /* 两个按钮，一个为拍照按钮，另一个是开启摄像头按钮 */

    QWidget *ye1,*ye2,*ye3,*main;
    QListWidget *xuan;

    QImage saveImage;           /* 拍照保存的照片 */
    Camera *camera;             /* 摄像头设备 */

    void layoutInit();          /* 布局初始化 */
    void scanCameraDevice();    /* 扫描是否存在摄像头 */
public:
    Mat myImg;
    QImage myQImg;

private slots:
    void showImage(const QImage&);  /* 显示图像 */
    void setButtonText(bool);       /* 设置按钮文本 */
    void saveImageToLocal();        /* 保存照片到本地 */
    void chuli();
    void baocun();

};
#endif // MAINWINDOW_H
