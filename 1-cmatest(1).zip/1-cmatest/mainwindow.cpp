#include "mainwindow.h"
#include "camera.h"

#include <QGuiApplication>
#include <QScreen>
#include <QFile>
#include <QPixmap>
#include <QBuffer>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    layoutInit();       /* 布局初始化 */
    scanCameraDevice(); /* 扫描摄像头 */
}

MainWindow::~MainWindow()
{
}

void MainWindow::layoutInit()
{

    QList <QScreen *> list_screen =  QGuiApplication::screens();
    /* 否则则设置主窗体大小为800x480 */
    this->resize(800, 480);

    /* 实例化与布局，常规操作 *//* 摄像头 */
    camera = new Camera(this);
    main = new QWidget(this);
    main->setMinimumSize(800,480);
    this->setCentralWidget(main);
    ye1 = new QWidget;
    ye2 = new QWidget;
    ye3 = new QWidget;
    QTabWidget *tab;
    tab = new QTabWidget;
    xuan = new QListWidget;
    mainWidget = new QWidget();
    up = new QWidget();
    right = new QWidget();
    xia = new QWidget();
    tu = new QWidget();
    comboBox = new QComboBox();
    pushButton[0] = new QPushButton();
    pushButton[1] = new QPushButton();
    pushButton[2] = new QPushButton();
    pushButton[3] = new QPushButton();

    scrollArea = new QScrollArea();
    displayLabel = new QLabel(scrollArea);
    gun1 = new QScrollArea();
    gun2 = new QScrollArea();
    photoLabel = new QLabel(gun1);
    chu = new QLabel(gun2);
    chu2 = new QLabel(gun2);
    vboxLayout = new QVBoxLayout();
    heng2 = new QHBoxLayout();
    hboxLayout = new QHBoxLayout();


//布局设置
    vboxLayout->addWidget(comboBox);
    vboxLayout->addWidget(pushButton[1]);
    vboxLayout->addWidget(pushButton[0]);
    right->setLayout(vboxLayout);
    hboxLayout->addWidget(right);
    hboxLayout->addWidget(scrollArea);
    ye1->setLayout(hboxLayout);

    heng1 = new QHBoxLayout;
    heng1->addWidget(pushButton[2]);
    heng1->addWidget(pushButton[3]);
    up->setLayout(heng1);
    heng2->addWidget(gun1);
    heng2->addWidget(gun2);
    xia->setLayout(heng2);
    shu = new QVBoxLayout;
    shu->addWidget(up);
    shu->addWidget(xia);
    ye2->setLayout(shu);

    tab->addTab(ye1,"视频拍照");
    tab->addTab(ye2,"旋转放缩处理");
    //tab->addTab(ye3,"图像超分");
    QHBoxLayout *chui;
    chui = new QHBoxLayout;
    chui->addWidget(tab);
    main->setLayout(chui);

    //器件的参数设置
    pushButton[0]->setMaximumHeight(40);
    pushButton[0]->setMaximumWidth(200);
    pushButton[1]->setMaximumHeight(40);
    pushButton[1]->setMaximumWidth(200);
    pushButton[2]->setMaximumHeight(40);
    pushButton[2]->setMaximumWidth(200);
    pushButton[3]->setMaximumHeight(40);
    pushButton[3]->setMaximumWidth(200);
    comboBox->setMaximumHeight(40);
    comboBox->setMaximumWidth(200);
    scrollArea->setMinimumWidth(300);
    gun1->setMinimumWidth(200);
    gun2->setMinimumWidth(200);

    //显示图像最大画面为xx
    displayLabel->setMinimumWidth(scrollArea->width() * 0.75);
    displayLabel->setMinimumHeight(scrollArea->height() * 0.75);
    scrollArea->setWidget(displayLabel);
    photoLabel->setMinimumWidth(gun1->width() * 0.55);
    photoLabel->setMinimumHeight(gun1->height() * 0.55);
    gun1->setWidget(photoLabel);
    chu->setMinimumWidth(gun2->width() * 2.15);
    chu->setMinimumHeight(gun2->height() * 2.15);
    gun2->setWidget(chu);
    /* 居中显示 */
    scrollArea->setAlignment(Qt::AlignCenter);
    gun1->setAlignment(Qt::AlignCenter);
    gun2->setAlignment(Qt::AlignCenter);

    /* 自动拉伸 */
    displayLabel->setScaledContents(true);


    /* 设置一些属性 */
    pushButton[0]->setText("拍照");
    pushButton[0]->setEnabled(false);
    pushButton[1]->setText("开始");
    pushButton[1]->setCheckable(true);
    pushButton[2]->setText("处理");
    pushButton[2]->setCheckable(false);
    pushButton[3]->setText("保存");

    /* 信号连接槽 */
    connect(camera, SIGNAL(readyImage(QImage)),this, SLOT(showImage(QImage)));
    connect(pushButton[1], SIGNAL(clicked(bool)),camera, SLOT(cameraProcess(bool)));
    connect(pushButton[1], SIGNAL(clicked(bool)),this, SLOT(setButtonText(bool)));
    connect(pushButton[0], SIGNAL(clicked()),this, SLOT(saveImageToLocal()));
    connect(pushButton[2], SIGNAL(clicked()),this, SLOT(chuli()));
    connect(pushButton[3], SIGNAL(clicked()),this, SLOT(baocun()));

}

void MainWindow::scanCameraDevice()
{
    /* 如果是Windows系统，是摄像头0 */
    comboBox->addItem("windows摄像头0");
    connect(comboBox,SIGNAL(currentIndexChanged(int)),camera, SLOT(selectCameraDevice(int)));
}



void MainWindow::showImage(const QImage &image)
{
    /* 显示图像 */
    displayLabel->setPixmap(QPixmap::fromImage(image));
    saveImage = image;

    /* 判断图像是否为空，空则设置拍照按钮不可用 */
    if (!saveImage.isNull()){
        pushButton[0]->setEnabled(true);
        pushButton[2]->setEnabled(true);
    }
    else{
        pushButton[0]->setEnabled(false);
        pushButton[2]->setEnabled(false);
    }

}



void MainWindow::setButtonText(bool bl)
{
    if (bl) {
        /* 设置摄像头设备 */
        camera->selectCameraDevice(comboBox->currentIndex());
        pushButton[1]->setText("关闭");
    } else {
        /* 若关闭了摄像头则禁用拍照按钮 */
        pushButton[0]->setEnabled(false);
        pushButton[1]->setText("开始");
    }
}

void MainWindow::saveImageToLocal()
{
    /* 判断图像是否为空 QCoreApplication::applicationDirPath() + */
    /* save(arg1，arg2，arg3)重载函数，arg1代表路径文件名，* arg2保存的类型，arg3代表保存的质量等级 */
    if (!saveImage.isNull()) {
        QString fileName = "D:\\3--work\\0--qt\\0-pic\\test.png";
        qDebug()<<"正在保存"<<fileName<<"图片,请稍候..."<<endl;
        saveImage.save(fileName, "PNG", -1);

        Mat src = imread(fileName.toLatin1().data());
        cvtColor(src,src,COLOR_BGR2RGB);
        myImg = src;
        qDebug() << src.size().width;
        qDebug() << src.size().height;
        myQImg = QImage((const unsigned char*)(src.data),src.cols,src.rows,QImage::Format_RGB888);
        photoLabel->setPixmap(QPixmap::fromImage(myQImg.scaled(photoLabel->size(),Qt::KeepAspectRatio)));
        qDebug()<<"保存完成！"<<endl;
    }
}

void MainWindow::chuli()
{
    QString fileName = "D:\\3--work\\0--qt\\0-pic\\test.png";
    Mat src = imread(fileName.toLatin1().data());
    cvtColor(src,src,COLOR_BGR2RGB);
    myImg = src;

    //放大图像//重新定义尺寸//打印尺寸
    Mat dst2;
    cv::resize(src,dst2,Size(1880,1560),0,0,INTER_CUBIC);    //
    qDebug() << dst2.size().width;
    qDebug() << dst2.size().height;
    myImg = dst2;
    myQImg = QImage((const unsigned char*)(dst2.data),dst2.cols,dst2.rows,QImage::Format_RGB888);
    chu->setPixmap(QPixmap::fromImage(myQImg.scaled(chu->size(),Qt::KeepAspectRatio)));
}

void MainWindow::baocun()
{
    QString cun = "D:\\3--work\\0--qt\\0-pic\\fang.png";
    qDebug()<<"正在保存"<<cun<<"图片,请稍候..."<<endl;
    saveImage.save(cun, "PNG", -1);
    qDebug()<<"处理图片-保存完成！"<<endl;

}
