#ifndef CAMERA_H
#define CAMERA_H

#include <QImage>
#include <QTimer>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <opencv2/imgproc.hpp>
#include <opencv2/dnn_superres.hpp>
/* 使用命名空间cv下的VideoCapture与Mat类 */

namespace cv {
class VideoCapture;
class Mat;
}


class Camera : public QObject
{
    Q_OBJECT
public:
    explicit Camera(QObject *parent = nullptr);
    ~Camera();

signals:
    void readyImage(const QImage&);         /* 声明信号，用于传递有图片信号时显示图像 */

public slots:
    bool cameraProcess(bool);               /* 用于开启定时器 */
    void selectCameraDevice(int);           /* 选择摄像头 */

private slots:
    void timerTimeOut();                    /* 定时器时间到处理函数，发送图像数据信号 */
private:
    cv::VideoCapture * capture;             /* 声明OpenCV的cv命名空间下的VideoCapture对象 */
    QTimer * timer;                         /* 定时器，定时处理获取图像 */
    QImage matToQImage(const cv::Mat&);     /* 图像转换处理函数 */
};

#endif // CAMERA_H


